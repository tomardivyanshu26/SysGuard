import tkinter as tk
from tkinter import ttk, simpledialog, messagebox
from monitor import process_manager

class ProcessTreeFrame(tk.Frame):
    def __init__(self, master, on_action_callback=None):
        super().__init__(master)
        self.on_action_callback = on_action_callback
        cols = ("PID", "Name", "PPID", "CPU%", "RAM%", "Threads", "Nice")
        self.tree = ttk.Treeview(self, columns=cols, show='headings', height=15)
        for col in cols:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=110)
        self.tree.pack(side="left", fill="both", expand=True)

        sb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscroll=sb.set)
        sb.pack(side="right", fill="y")

        self.menu = tk.Menu(self, tearoff=0)
        self.menu.add_command(label="Terminate", command=lambda: self._do_action("terminate"))
        self.menu.add_command(label="Suspend", command=lambda: self._do_action("suspend"))
        self.menu.add_command(label="Resume", command=lambda: self._do_action("resume"))
        self.menu.add_command(label="Change Priority", command=self._change_priority)
        self.tree.bind("<Button-3>", self._show_menu)

    def _show_menu(self, event):
        try:
            self.menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.menu.grab_release()

    def populate(self):
        for r in self.tree.get_children():
            self.tree.delete(r)
        procs = process_manager.list_processes()
        for p in procs:
            self.tree.insert("", "end", values=(p.get('pid'), p.get('name'), p.get('ppid'), p.get('cpu_percent'), p.get('memory_percent'), p.get('num_threads'), p.get('nice')))

    def _selected_pid(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("No selection", "Select a process first")
            return None
        pid = int(self.tree.item(sel[0], 'values')[0])
        return pid

    def _do_action(self, action):
        pid = self._selected_pid()
        if pid is None:
            return
        if action == "terminate":
            ok, msg = process_manager.terminate_process(pid)
        elif action == "suspend":
            ok, msg = process_manager.suspend_process(pid)
        elif action == "resume":
            ok, msg = process_manager.resume_process(pid)
        else:
            ok, msg = False, "Unknown action"
        messagebox.showinfo("Result", f"{action} on PID {pid}: {msg}")
        if self.on_action_callback:
            self.on_action_callback()

    def _change_priority(self):
        pid = self._selected_pid()
        if pid is None:
            return
        answer = simpledialog.askinteger("Priority", "Enter new nice value (e.g., 10 or -5):")
        if answer is None:
            return
        ok, msg = process_manager.change_priority(pid, answer)
        messagebox.showinfo("Result", msg)
        if self.on_action_callback:
            self.on_action_callback()
