import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from monitor.system_stats import SystemStats
from monitor.resource_predictor import Predictor, moving_average
from gui.process_tree_gui import ProcessTreeFrame
from utils import config, logger
from algorithms.deadlock_detection import detect_deadlock
from monitor.process_manager import terminate_process 
from monitor.deadlock import run_bankers_algorithm
from monitor.scheduling import process_scheduling, thread_scheduling

import threading
import pandas as pd
import time
import os

class MainGUI:
    def __init__(self, root):
        self.root = root
        root.title("AI-Powered Activity Monitor — Enhanced")
        root.geometry("1100x700")

        self.stats = SystemStats()
        self.stats.start_background(interval=config.REFRESH_INTERVAL)
        self.cpu_predictor = Predictor(window=config.PREDICTION_WINDOW, model_name="cpu")
        self.ram_predictor = Predictor(window=config.PREDICTION_WINDOW, model_name="ram")

        top = tk.Frame(root)
        top.pack(fill="x", pady=6)
        self.cpu_label = tk.Label(top, text="CPU: --", font=("Arial", 14))
        self.cpu_label.pack(side="left", padx=8)
        self.ram_label = tk.Label(top, text="RAM: --", font=("Arial", 14))
        self.ram_label.pack(side="left", padx=8)
        self.cpu_pred_label = tk.Label(top, text="Pred CPU: --")
        self.cpu_pred_label.pack(side="left", padx=8)
        self.ram_pred_label = tk.Label(top, text="Pred RAM: --")
        self.ram_pred_label.pack(side="left", padx=8)
        tk.Button(top, text="Export Log CSV", command=self.export_log).pack(side="right", padx=8)

        chart_frame = tk.Frame(root)
        chart_frame.pack(side="left", fill="both", expand=True, padx=6)
        self.fig, (self.ax1, self.ax2) = plt.subplots(2,1, figsize=(6,5))
        plt.tight_layout()
        self.canvas = FigureCanvasTkAgg(self.fig, master=chart_frame)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

        right = tk.Frame(root)
        right.pack(side="right", fill="y", padx=6)
        self.proc_frame = ProcessTreeFrame(right, on_action_callback=self.refresh_process_tree)
        self.proc_frame.pack(fill="y", pady=6)

        alg_frame = tk.LabelFrame(right, text="Banker / Deadlock Tools")
        alg_frame.pack(fill="x", pady=6)
        tk.Button(alg_frame, text="Open Banker's Demo CSV", command=self.load_bankers_csv).pack(fill="x", pady=2)
        tk.Button(alg_frame, text="Run Deadlock Detection (demo)", command=self.run_deadlock_demo).pack(fill="x", pady=2)

        self.update_loop()

    def refresh_process_tree(self):
        self.proc_frame.populate()

    def update_loop(self):

        hist = self.stats.get_histories()
        cpu_hist = hist['cpu']
        ram_hist = hist['ram']
        disk_read = hist['disk_read']
        disk_write = hist['disk_write']

        if cpu_hist:
            cpu = cpu_hist[-1]
            self.cpu_label.config(text=f"CPU: {cpu:.1f}%")
        else:
            cpu = None
        if ram_hist:
            ram = ram_hist[-1]
            self.ram_label.config(text=f"RAM: {ram:.1f}%")
        else:
            ram = None

        cpu_pred = self.cpu_predictor.fit_and_predict(cpu_hist)
        ram_pred = self.ram_predictor.fit_and_predict(ram_hist)
        if cpu_pred is not None:
            self.cpu_pred_label.config(text=f"Pred CPU: {cpu_pred:.1f}% (LR)")
        else:
            self.cpu_pred_label.config(text="Pred CPU: --")
        if ram_pred is not None:
            self.ram_pred_label.config(text=f"Pred RAM: {ram_pred:.1f}% (LR)")
        else:
            self.ram_pred_label.config(text="Pred RAM: --")

        cpu_ma = moving_average(cpu_hist, k=5)
        ram_ma = moving_average(ram_hist, k=5)

        self.ax1.clear()
        self.ax2.clear()
        if cpu_hist:
            self.ax1.plot(cpu_hist[-300:], label="CPU")
            if cpu_pred is not None:

                self.ax1.scatter(len(cpu_hist[-300:]), cpu_pred, marker='x')
            self.ax1.set_ylim(0,100)
            self.ax1.set_ylabel("CPU%")
            self.ax1.legend()
        if ram_hist:
            self.ax2.plot(ram_hist[-300:], label="RAM")
            if ram_pred is not None:
                self.ax2.scatter(len(ram_hist[-300:]), ram_pred, marker='x')
            self.ax2.set_ylim(0,100)
            self.ax2.set_ylabel("RAM%")
            self.ax2.legend()
        self.canvas.draw_idle()

        self.refresh_process_tree()

        if config.LOG_ENABLED and cpu is not None and ram is not None:
            try:
                logger.log_sample(config.LOG_PATH, cpu, ram, disk_read[-1] if disk_read else 0, disk_write[-1] if disk_write else 0)
            except Exception:
                pass

        if cpu is not None and cpu > config.ALERT_CPU_THRESHOLD:
            messagebox.showwarning("CPU Alert", f"CPU high: {cpu:.1f}%")

        if ram is not None and ram > config.ALERT_RAM_THRESHOLD:
            messagebox.showwarning("RAM Alert", f"RAM high: {ram:.1f}%")

        self.root.after(int(config.REFRESH_INTERVAL*1000), self.update_loop)

    def export_log(self):
        if not os.path.exists(config.LOG_PATH):
            messagebox.showinfo("No Log", "No log file exists yet.")
            return
        dest = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV","*.csv")])
        if dest:
            import shutil
            shutil.copyfile(config.LOG_PATH, dest)
            messagebox.showinfo("Exported", f"Log exported to {dest}")

    def load_bankers_csv(self):
        path = filedialog.askopenfilename(filetypes=[("CSV","*.csv"),("Text","*.txt"),("All","*.*")])
        if not path:
            return
        with open(path) as f:
            lines = [ln.strip() for ln in f if ln.strip() and not ln.strip().startswith("#")]
        parts = []
        lines = [ln for ln in lines if ln]
        if len(lines) < 3:
            messagebox.showerror("Format", "File format not recognized.")
            return
        available = [int(x) for x in lines[0].split(',')]
        rem = lines[1:]
        if len(rem) % 2 != 0:
            messagebox.showerror("Format", "Allocation/Max lines parse error.")
            return
        half = len(rem)//2
        allocation = [[int(x) for x in ln.split(',')] for ln in rem[:half]]
        maximum = [[int(x) for x in ln.split(',')] for ln in rem[half:half*2]]
        safe, seq = run_bankers_algorithm(available, maximum, allocation)
        if safe:
            messagebox.showinfo("Banker", f"System is SAFE. Safe sequence (process indices): {seq}")
        else:
            messagebox.showwarning("Banker", "System is NOT safe (unsafe state).")

    def run_deadlock_demo(self):
        
        # 3 resources and 4 processes
        allocation = [
            [0,1,0],
            [2,0,0],
            [3,0,3],
            [2,1,1],
        ]
        request = [
            [0,0,0],
            [1,0,2],
            [3,0,0],
            [0,0,2],
        ]
        available = [0,0,0]
        deadlocked = detect_deadlock(request, allocation, available)
        if not deadlocked:
            messagebox.showinfo("Deadlock", "No deadlock detected in demo.")
        else:
            freed = terminate_process(deadlocked, allocation)
            messagebox.showwarning("Deadlock", f"Deadlocked processes indices: {deadlocked}\nRecovery by terminating some will free: {freed}")

def start_app():
    root = tk.Tk()
    app = MainGUI(root)
    root.mainloop()

if __name__ == "__main__":
    start_app()
