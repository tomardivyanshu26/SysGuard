import csv
import os
from datetime import datetime

def ensure_log_file(path):
    if not os.path.exists(os.path.dirname(path)):
        os.makedirs(os.path.dirname(path), exist_ok=True)
    if not os.path.exists(path):
        with open(path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['timestamp','cpu_percent','ram_percent','disk_read_bytes','disk_write_bytes'])

def log_sample(path, cpu, ram, read_bytes, write_bytes):
    ensure_log_file(path)
    ts = datetime.utcnow().isoformat()
    try:
        with open(path,'a',newline='') as f:
            writer = csv.writer(f)
            writer.writerow([ts, cpu, ram, read_bytes, write_bytes])
    except Exception:
        pass
