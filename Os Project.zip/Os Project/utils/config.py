# parameters
REFRESH_INTERVAL = 1  #in seconds for sampling
PREDICTION_WINDOW = 30
ALERT_CPU_THRESHOLD = 90.0  # percent
ALERT_RAM_THRESHOLD = 90.0  # percent
LOG_ENABLED = True
LOG_PATH = "logs/resource_log.csv"
