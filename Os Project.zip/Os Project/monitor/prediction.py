import numpy as np
from sklearn.linear_model import LinearRegression
import pickle
import os

MODEL_DIR = "models"
os.makedirs(MODEL_DIR, exist_ok=True)


def train_and_predict(timeseries, feature_name="cpu", window_size=5):
    
    model = train_predictor(timeseries, feature_name, window_size)
    recent = timeseries[-window_size:]
    prediction = predict_next(model, recent)
    return model, prediction

def prepare_data(timeseries, window_size=5):
    
    X, y = [], []
    for i in range(len(timeseries) - window_size):
        X.append(timeseries[i:i+window_size])
        y.append(timeseries[i+window_size])
    return np.array(X), np.array(y)

def train_predictor(timeseries, feature_name="cpu", window_size=5):
    
    X, y = prepare_data(timeseries, window_size)
    model = LinearRegression()
    model.fit(X, y)
    
    model_path = os.path.join(MODEL_DIR, f"{feature_name}_lr_model.pkl")
    with open(model_path, "wb") as f:
        pickle.dump(model, f)
    
    print(f"[INFO] Trained {feature_name} predictor saved at {model_path}")
    return model

def load_predictor(feature_name="cpu"):

    model_path = os.path.join(MODEL_DIR, f"{feature_name}_lr_model.pkl")
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"No model found for {feature_name}. Train first!")
    
    with open(model_path, "rb") as f:
        model = pickle.load(f)
    return model

def predict_next(model, recent_data):
    
    recent_data = np.array(recent_data).reshape(1, -1)
    return model.predict(recent_data)[0]

if __name__ == "__main__":

    import random

    cpu_usage = [random.uniform(10, 80) for _ in range(50)]
    window_size = 5

    cpu_model = train_predictor(cpu_usage, "cpu", window_size)

    recent = cpu_usage[-window_size:]
    prediction = predict_next(cpu_model, recent)
    print(f"Next predicted CPU usage: {prediction:.2f}%")
