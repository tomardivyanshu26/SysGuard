import psutil
import os
import threading

def list_processes():
    """Return list of process info dicts."""
    procs = []
    for proc in psutil.process_iter(['pid', 'ppid', 'name', 'username', 'cpu_percent', 'memory_percent', 'num_threads', 'status', 'nice']):
        try:
            info = proc.info
            procs.append(info)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return procs

def get_process_children(pid):
    """Return list of child process info for a pid."""
    try:
        p = psutil.Process(pid)
        return [c.as_dict(attrs=['pid','name','cpu_percent','memory_percent','status','nice']) for c in p.children(recursive=False)]
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return []

def get_threads(pid):
    """Return thread info for a process (id, user_time, system_time)."""
    try:
        p = psutil.Process(pid)
        threads = p.threads()
        return [{'id': t.id, 'user_time': t.user_time, 'system_time': t.system_time} for t in threads]
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return []

def terminate_process(pid):
    try:
        p = psutil.Process(pid)
        p.terminate()
        return True, "terminated"
    except Exception as e:
        return False, str(e)

def suspend_process(pid):
    try:
        p = psutil.Process(pid)
        p.suspend()
        return True, "suspended"
    except Exception as e:
        return False, str(e)

def resume_process(pid):
    try:
        p = psutil.Process(pid)
        p.resume()
        return True, "resumed"
    except Exception as e:
        return False, str(e)

def change_priority(pid, nice_value):
    """Change process nice (priority). Lower = higher priority on Unix. On Windows, maps to priority classes."""
    try:
        p = psutil.Process(pid)
        p.nice(nice_value)
        return True, f"nice set to {nice_value}"
    except Exception as e:
        return False, str(e)
