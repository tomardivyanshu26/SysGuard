import pickle
import numpy as np
from sklearn.linear_model import LinearRegression
from collections import deque
import os

MODEL_DIR = "models"
if not os.path.exists(MODEL_DIR):
    os.makedirs(MODEL_DIR)

class Predictor:
    """Simple predictor using sliding-window linear regression.
       Fast, lightweight for project/demo; you can replace with LSTM later.
    """
    def __init__(self, window=30, model_name="cpu"):
        self.window = window
        self.model = LinearRegression()
        self.model_name = model_name
        self.model_path = os.path.join(MODEL_DIR, f"{model_name}_lr.pkl")

        if os.path.exists(self.model_path):
            try:
                with open(self.model_path, "rb") as f:
                    self.model = pickle.load(f)
            except Exception:
                self.model = LinearRegression()

    def fit_and_predict(self, history):
        """Fit on last `window` samples and predict next point."""
        if len(history) < 5:
            return None
        h = list(history)[-self.window:]
        X = np.arange(len(h)).reshape(-1,1)
        y = np.array(h)
        self.model.fit(X, y)
        next_pred = self.model.predict(np.array([[len(h)]]))[0]
        
        try:
            with open(self.model_path, "wb") as f:
                pickle.dump(self.model, f)
        except Exception:
            pass
        return float(next_pred)

def moving_average(history, k=5):
    if len(history) == 0:
        return None
    arr = np.array(history)
    return float(np.mean(arr[-k:])) if len(arr) >= k else float(np.mean(arr))
