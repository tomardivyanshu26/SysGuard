def run_bankers_algorithm():
    print("\n=== Deadlock Detection using Banker's Algorithm ===")

    processes = 5
    resources = 3

    alloc = [[0, 1, 0],
             [2, 0, 0],
             [3, 0, 2],
             [2, 1, 1],
             [0, 0, 2]]

    max_need = [[7, 5, 3],
                [3, 2, 2],
                [9, 0, 2],
                [2, 2, 2],
                [4, 3, 3]]

    avail = [3, 3, 2]

    need = [[max_need[i][j] - alloc[i][j] for j in range(resources)] for i in range(processes)]
    finish = [0] * processes
    safe_seq = []

    work = avail[:]

    while True:
        found = False
        for p in range(processes):
            if finish[p] == 0 and all(need[p][j] <= work[j] for j in range(resources)):
                for j in range(resources):
                    work[j] += alloc[p][j]
                safe_seq.append(p)
                finish[p] = 1
                found = True
        if not found:
            break

    if all(finish):
        print("✅ System is in a SAFE state.")
        print("Safe sequence:", " -> ".join("P"+str(p) for p in safe_seq))
    else:
        print("⚠️ Deadlock detected! System is NOT in a safe state.")
