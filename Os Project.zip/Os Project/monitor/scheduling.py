import random

def process_scheduling():
    print("\n=== Process Scheduling (FCFS Example) ===")
    processes = ["P1", "P2", "P3", "P4"]
    burst_time = [6, 8, 7, 3]

    waiting_time = [0] * len(processes)
    turnaround_time = [0] * len(processes)

    for i in range(1, len(processes)):
        waiting_time[i] = waiting_time[i-1] + burst_time[i-1]

    for i in range(len(processes)):
        turnaround_time[i] = waiting_time[i] + burst_time[i]

    print("Process\tBurst\tWaiting\tTurnaround")
    for i in range(len(processes)):
        print(f"{processes[i]}\t{burst_time[i]}\t{waiting_time[i]}\t{turnaround_time[i]}")

def thread_scheduling():
    print("\n=== Thread Scheduling (Round Robin Example) ===")
    threads = ["T1", "T2", "T3", "T4"]
    burst_time = [10, 5, 8, 6]
    quantum = 3

    rem_bt = burst_time[:]
    t = 0

    while True:
        done = True
        for i in range(len(threads)):
            if rem_bt[i] > 0:
                done = False
                if rem_bt[i] > quantum:
                    t += quantum
                    rem_bt[i] -= quantum
                else:
                    t += rem_bt[i]
                    rem_bt[i] = 0
                    print(f"{threads[i]} finished at time {t}")
        if done:
            break
