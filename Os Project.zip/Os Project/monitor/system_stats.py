import psutil
import numpy as np
from sklearn.linear_model import LinearRegression

cpu_history = []
ram_history = []

cpu_model = LinearRegression()
ram_model = LinearRegression()

def get_system_stats():
    """Fetch CPU and RAM usage in percentage."""
    cpu = psutil.cpu_percent(interval=1)
    ram = psutil.virtual_memory().percent
    cpu_history.append(cpu)
    ram_history.append(ram)
    return cpu, ram

def predict_usage(history, model):
    """Predict next CPU/RAM value using Linear Regression."""
    if len(history) < 5:
        return None
    X = np.arange(len(history)).reshape(-1, 1)
    y = np.array(history)
    model.fit(X, y)
    return model.predict(np.array([[len(history)]]))[0]
