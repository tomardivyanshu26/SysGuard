def thread_round_robin(threads, quantum=1):
    from collections import deque
    q = deque(threads)
    time, schedule = 0, []
    while q:
        tid, bt = q.popleft()
        if bt > quantum:
            time += quantum
            q.append((tid, bt - quantum))
        else:
            time += bt
        schedule.append((tid, time))
    return schedule
