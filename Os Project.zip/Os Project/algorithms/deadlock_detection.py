def detect_deadlock(alloc, request, avail):
    n = len(alloc)
    m = len(avail)
    finish = [False] * n
    work = avail[:]

    while True:
        found = False
        for i in range(n):
            if not finish[i] and all(request[i][j] <= work[j] for j in range(m)):
                for j in range(m):
                    work[j] += alloc[i][j]
                finish[i] = True
                found = True
        if not found:
            break

    deadlocked = [i for i in range(n) if not finish[i]]
    return deadlocked


if __name__ == "__main__":
    alloc = [[0, 1, 0],
             [2, 0, 0],
             [3, 0, 3],
             [2, 1, 1],
             [0, 0, 2]]
    request = [[0, 0, 0],
               [2, 0, 2],
               [0, 0, 0],
               [1, 0, 0],
               [0, 0, 2]]
    avail = [0, 0, 0]

    deadlocked = detect_deadlock(alloc, request, avail)
    print("Deadlocked processes:", deadlocked if deadlocked else "No deadlock")
