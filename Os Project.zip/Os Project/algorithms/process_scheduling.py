def fcfs(processes):
    processes.sort(key=lambda x: x[1])  
    time = 0
    schedule = []
    for pid, at, bt in processes:
        time = max(time, at) + bt
        schedule.append((pid, time))
    return schedule


def sjf(processes):
    processes.sort(key=lambda x: (x[1], x[2]))  
    time, schedule = 0, []
    while processes:
        ready = [p for p in processes if p[1] <= time]
        if not ready:
            time = processes[0][1]
            continue
        proc = min(ready, key=lambda x: x[2])
        processes.remove(proc)
        time += proc[2]
        schedule.append((proc[0], time))
    return schedule


def round_robin(processes, quantum=2):
    from collections import deque
    queue = deque(processes)
    time, schedule = 0, []
    while queue:
        pid, at, bt = queue.popleft()
        if bt > quantum:
            time += quantum
            queue.append((pid, at, bt - quantum))
        else:
            time += bt
        schedule.append((pid, time))
    return schedule
