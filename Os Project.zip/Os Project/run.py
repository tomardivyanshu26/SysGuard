from monitor.system_stats import get_system_stats, predict_usage, cpu_history, ram_history, cpu_model, ram_model
from algorithms.bankers import bankers_algorithm
from algorithms.deadlock_detection import detect_deadlock
from algorithms.process_scheduling import fcfs, sjf, round_robin
from algorithms.thread_scheduling import thread_round_robin

def main_menu():
    while True:
        print("\n===== AI-Powered OS Monitor =====")
        print("1. View System Stats & Predictions")
        print("2. Run Banker’s Algorithm (Deadlock Avoidance)")
        print("3. Run Deadlock Detection")
        print("4. Process Scheduling (FCFS, SJF, RR)")
        print("5. Thread Scheduling")
        print("6. Exit")

        choice = input("Enter choice: ")

        if choice == "1":
            cpu, ram = get_system_stats()
            print(f"CPU: {cpu}% | RAM: {ram}%")
            cpu_pred = predict_usage(cpu_history, cpu_model)
            ram_pred = predict_usage(ram_history, ram_model)
            print(f"Predicted CPU: {cpu_pred} | Predicted RAM: {ram_pred}")

        elif choice == "2":
            # Example input
            alloc = [[0, 1, 0], [2, 0, 0], [3, 0, 2], [2, 1, 1], [0, 0, 2]]
            max_need = [[7, 5, 3], [3, 2, 2], [9, 0, 2], [2, 2, 2], [4, 3, 3]]
            avail = [3, 3, 2]
            safe, seq = bankers_algorithm(alloc, max_need, avail)
            print("Safe sequence:", seq if safe else "UNSAFE")

        elif choice == "3":
            alloc = [[0, 1, 0], [2, 0, 0], [3, 0, 3], [2, 1, 1], [0, 0, 2]]
            request = [[0, 0, 0], [2, 0, 2], [0, 0, 0], [1, 0, 0], [0, 0, 2]]
            avail = [0, 0, 0]
            deadlocked = detect_deadlock(alloc, request, avail)
            print("Deadlocked processes:", deadlocked if deadlocked else "No deadlock")

        elif choice == "4":
            processes = [(1,0,5), (2,1,3), (3,2,8)]
            print("FCFS:", fcfs(processes.copy()))
            print("SJF:", sjf(processes.copy()))
            print("RR:", round_robin(processes.copy(), quantum=2))

        elif choice == "5":
            threads = [(1, 4), (2, 3), (3, 5)]
            print("Thread Round Robin:", thread_round_robin(threads, quantum=2))

        elif choice == "6":
            break
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main_menu()
